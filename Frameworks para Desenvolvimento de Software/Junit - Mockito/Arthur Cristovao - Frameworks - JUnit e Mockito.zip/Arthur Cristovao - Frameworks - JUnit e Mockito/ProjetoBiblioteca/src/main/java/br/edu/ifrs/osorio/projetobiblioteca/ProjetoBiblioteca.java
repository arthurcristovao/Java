package br.edu.ifrs.osorio.projetobiblioteca;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



/**
 *
 * @author Arthur
 */
public class ProjetoBiblioteca {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
