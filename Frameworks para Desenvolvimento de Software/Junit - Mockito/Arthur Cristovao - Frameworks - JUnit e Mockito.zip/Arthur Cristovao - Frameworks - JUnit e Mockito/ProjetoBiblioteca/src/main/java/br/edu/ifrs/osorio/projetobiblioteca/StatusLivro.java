package br.edu.ifrs.osorio.projetobiblioteca;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */


/**
 *
 * @author Arthur
 */
public enum StatusLivro {
    DISPONIVEL, RESERVADO, LOCADO;
}
