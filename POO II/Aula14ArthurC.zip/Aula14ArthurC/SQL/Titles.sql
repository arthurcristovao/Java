USE	sistema;

CREATE TABLE titles (
    ISBN INT PRIMARY KEY,
    Title VARCHAR(255),
    EditionNumber VARCHAR(50),
    Copyright VARCHAR(50)
);
