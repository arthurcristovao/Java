/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 08220186
 */
public class ChamadaContaBancaria {
    public static void main(String[] args) {
        ContaBancaria c1 = new ContaBancaria();
        
        c1.agencia = 100;
        c1.numero = 100000;
        c1.digito = 1;
        c1.saldo = 100;
        
        c1.depositar(50);
        System.out.println(c1.saldo);
        
        
        ContaBancaria c2 = new ContaBancaria();
        c2.agencia = 200;
        c2.numero = 200000;
        c2.digito = 2;
        c2.saldo = 200;
         

        System.out.println(c2.saldo);
        c1.transferir(50, c2);
        System.out.println(c2.saldo);
        
        
    }
}
