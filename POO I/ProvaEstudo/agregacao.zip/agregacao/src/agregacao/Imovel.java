/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agregacao;

/**
 *
 * @author Arthur
 */
public class Imovel {
    private Corretor corretor;
    private String registro;
    private double valorAluguel;
    private boolean status;
    
    public Imovel(String registro, double valorAluguel){
        this.registro = registro;
        this.valorAluguel = valorAluguel;
    }
    
    public Corretor getCorretor() {
        return corretor;
    }
    
    public void setCorretor(Corretor corretor) {
        this.corretor = corretor;
    }

    public String getRegistro() {
        return registro;
    }

    public void setRegistro(String registro) {
        this.registro = registro;
    }

    public double getValorAluguel() {
        return valorAluguel;
    }

    public void setValorAluguel(double valorAluguel) {
        this.valorAluguel = valorAluguel;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
    
    
    
}
