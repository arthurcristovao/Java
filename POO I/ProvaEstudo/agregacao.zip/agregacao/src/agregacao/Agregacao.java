/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package agregacao;

/**
 *
 * @author Arthur
 */
public class Agregacao {
    public static void main(String[] args) {
        
        Imovel i = new Imovel("4444", 1000);
        Corretor c = new Corretor("João", 18);
        
        i.setCorretor(c);
        
        System.out.println(i.getCorretor());
    }
    
}
