package controle;

import entidade.Carta;
import java.util.Random;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author mk
 */
public class Baralho {

    public static void main(String[] args) {
//        Carta c1 = new Carta("paus", "preto", 9);
//        System.out.println("\nCarta cor = " + c1.getCor() + 
//                            "\nnaipe = " + c1.getNaipe() + 
//                            "\nnumero = " + c1.getNumero());
//        
//        Carta c2 = new Carta("estrela", "amarelo", -1);
//        System.out.println("\nCarta cor = " + c2.getCor() + 
//                            "\nnaipe = " + c2.getNaipe() + 
//                            "\nnumero = " + c2.getNumero());
//        
//        Carta c3 = new Carta(null, null, 0);
//        System.out.println("\nCarta cor = " + c3.getCor() + 
//                            "\nnaipe = " + c3.getNaipe() + 
//                            "\nnumero = " + c3.getNumero());

//        Carta[] baralhoPaus = new Carta[13];
//        baralhoPaus[0] = new Carta("paus", "preto", 1);
//        baralhoPaus[1] = new Carta("paus", "preto", 2);
//        baralhoPaus[2] = new Carta("paus", "preto", 3);
//        baralhoPaus[3] = new Carta("paus", "preto", 4);
//        baralhoPaus[4] = new Carta("paus", "preto", 5);
//        baralhoPaus[5] = new Carta("paus", "preto", 6);
//        baralhoPaus[6] = new Carta("paus", "preto", 7);
//        baralhoPaus[7] = new Carta("paus", "preto", 8);
//        baralhoPaus[8] = new Carta("paus", "preto", 9);
//        baralhoPaus[9] = new Carta("paus", "preto", 10);
//        baralhoPaus[10] = new Carta("paus", "preto", 11);
//        baralhoPaus[11] = new Carta("paus", "preto", 12);
//        baralhoPaus[12] = new Carta("paus", "preto", 13);
        Carta[] baralhoPaus = criarBaralho("paus");
        mostrarBaralho(baralhoPaus);
        Carta c = sortearCarta(baralhoPaus);
        System.out.println("Carta sorteada = " + c);
        Carta[] baralhoCopas = criarBaralho("copas");
        Carta[] baralhoOuros = criarBaralho("ouros");
        Carta[] baralhoEspadas = criarBaralho("espadas");
        Carta[] baralhoMisturado = embaralharCartas(baralhoPaus, baralhoCopas, baralhoOuros, baralhoEspadas);

    } //fecha main

    //O método é estático porque o main é estático
    public static Carta[] criarBaralho(String naipe) {
        Carta[] baralho = new Carta[13];
        if (naipe.equalsIgnoreCase("paus") || naipe.equalsIgnoreCase("espadas")) {
            for (int i = 0; i < 13; i++) {
                baralho[i] = new Carta(naipe, "preto", i + 1);
            }
        } else {
            if (naipe.equalsIgnoreCase("copas") || naipe.equalsIgnoreCase("ouros")) {
                for (int i = 0; i < 13; i++) {
                    baralho[i] = new Carta(naipe, "vermelho", i + 1);
                }
            } else {
                return null;
            }
        }
        return baralho;
    } // fechar criarBaralho

    public static void mostrarBaralho(Carta[] baralho) {
        if (baralho != null) {
            for (int i = 0; i < 13; i++) {
                System.out.println(baralho[i]);
            }
        } else {
            System.out.println("O baralho não foi criado !");
        }
    } //fecha mostrarBaralho
    
    public static Carta sortearCarta(Carta[] baralho){
        Random r = new Random();
        int i = r.nextInt(13);
        //System.out.println("numero sorteado = " + i);
        return baralho[i];
    }
    
    
    public static Carta[] embaralharCartas (Carta[] paus, Carta[] copas, Carta[] ouros, Carta[] espadas){
        Carta[] baralho = new Carta[52];
        // Desenvolver uma lógica para juntar os baralhos de modo a misturar as cartas
         return baralho;
    }
    
} //fecha classe

