package lib.interfaces;

public interface BotoesUteis {
    public void voltar ();
}
